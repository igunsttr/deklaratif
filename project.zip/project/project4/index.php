<!DOCTYPE html>
<html><head><title>Website ku</title>
<link rel="stylesheet" type="text/css" href="http://localhost/project3/style.css">
</head>
<body>
<div id="container">
<div id="image"></div>
<div id="header">
<ul>
<li><a href="http://localhost/project3/index.html">Home</a></li>
<li><a href="http://localhost/project3/profil.html">profil</a></li>
<li><a href="http://localhost/project3/contact.html">contact</a></li>
</ul>
</div>
<div id="nav">
<ul>
<li><a href="http://localhost/project3/index.html">Home</a></li>
<li><a href="http://localhost/project3/profil.html">profil</a></li>
<li><a href="http://localhost/project3/contact.html">contact</a></li>
</ul>
</div>
<div id="section">
<h1></h1>
<h2>Praktikum Web Project 4 - PHP, MYSQL dan CSS</h2>
<br />
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ltedb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT nama, alamat FROM mahasiswa";
$result = $conn->query($sql);

$x=1;
if ($result->num_rows > 0) {
    echo "<table border=1px><tr><th>no</th><th>Nama</th><th>Alamat</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$x."</td><td>".$row["nama"]."</td> <td>".$row["alamat"]."</td></tr>";
		$x=$x+1;
    }
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();
?>

</div>
<div id="footer">Copyright &copy; STT-Ibnu SinaBatam.</div>
</div>
</body>
</html>