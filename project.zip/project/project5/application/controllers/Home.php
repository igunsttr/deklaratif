<?php if (!defined('BASEPATH')) exit('Access Denied');
class Home extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	}
	public function index()
	{
		$this->home();
	}
	public function home()
	{
		$this->load->view('view_home'); //memanggil view home.php
	}
	public function mahasiswa() 
	{
		$this->load->view('view_mahasiswa'); //memanggil view kuliah.php
	}
	public function karyawan()
	{
		$this->load->view('view_karyawan'); //memanggil view kerja.php
	}
	public function dosen()
	{
		$this->load->view('view_dosen'); //memanggil view aboutme.php
	}
	public function jurusan()
	{
		$this->load->view('view_jurusan'); //memanggil view contact.php
	}
}
