<!DOCTYPE html> 
<html><head><title>Website ku</title><link rel="stylesheet" type="text/css" href="http://localhost/project5/assets/style.css"></head> 
<body> 
<div id="container"> 
<div id="image"></div> 
<div id="header"> 
<ul> 
<li><a href="http://localhost/project5/">Home</a></li> 
<li><a href="http://localhost/project5/index.php/home/mahasiswa">Mahasiswa</a></li> 
<li><a href="http://localhost/project5/index.php/home/dosen">Dosen</a></li> 
<li><a href="http://localhost/project5/index.php/home/karyawan">Karyawan</a></li> 
<li><a href="http://localhost/project5/index.php/home/jurusan">Jurusan</a></li> 
</ul> 
</div> 
<div id="nav"> 
<ul> 
<li><a href="http://localhost/project5/">Home</a></li> 
<li><a href="http://localhost/project5/index.php/home/mahasiswa">Mahasiswa</a></li> 
<li><a href="http://localhost/project5/index.php/home/dosen">Dosen</a></li> 
<li><a href="http://localhost/project5/index.php/home/karyawan">Karyawan</a></li> 
<li><a href="http://localhost/project5/index.php/home/jurusan">Jurusan</a></li> 
</ul> 
</div> 
<div id="section"> 
<h1>Web pertamaku</h1> 
<h2>Ini adalah web pertamaku dengan CODEIGNITER Framework</h2> 
<h3>Ini halaman Dosen</h3>
<p>Tulis disini</p>
</div> 
<div id="footer">Copyright &copy; STT-Ibnu SinaBatam.</div> 
</div> 
</body> 
</html>