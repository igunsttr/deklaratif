<?php if(!defined('BASEPATH')) exit('Access Denied');

class Template 
{
	public $CI;
	public function __construct()
	{
		$this->CI = &get_instance();
		//$this->CI->load->model('login_model');
		$this->load->view_data['base_url']=base_url();
	//	$this->CI->load->library('access');
	}
	
	public function index()
	{
		$this->home();
	}
	

	
	public function home($input, $output=NULL)
	{
		
		$data['page_title']='Home';
		$data['h1']='<h1>SISTEM INFORMASI AKADEMIK</h1>';
        $data['welcome']='<p>Selamat Datang di SIMAK STT IBNU SINA</p>';

        //Untuk mengirim variabel $input(berisi data model kiriman dari controller) ke /view/view_home.php
		$data['tabel']=$this->CI->load->view('view_home',$input,true);

		//untuk mengirim variabel $data[] baris atas ke /view/frame.php (template LTE)
		$output['data']=$this->CI->load->view('frame',$data,true);	

		//mengirim variabel $output ke controller - home
		RETURN $output;
	}


	public function tampil_jurusan($input, $output=NULL)
	{
		$data['base_url']=base_url();
	//true, jika hasil view tdk ingin lansung dicetak, tetapi disimpan di variabel $data['dataview']
        //Untuk mengirim variabel $input(berisi data model kiriman dari controller) ke /view/view_home.php
		$data['dataview']=$this->CI->load->view('view_home',$input,true);

		//tdk true, karena langsung di cetak di frame.php
		//untuk mengirim variabel $data[] baris atas ke /view/frame.php (template LTE)
		$output['data']=$this->CI->load->view('frame', $data);	

	}
}