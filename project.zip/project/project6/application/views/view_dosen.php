<?php 
echo $tabel; // mencetak variabel $tabel kiriman dari /librari/Template.php fungsi home

?>