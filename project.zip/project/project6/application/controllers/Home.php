<?php if (!defined('BASEPATH')) exit('Access Denied');
class Home extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->library('template');
		$this->load->view_data['base_url']=base_url();
		//$this->load->library('access');
		//$this->load->library('session');
		$this->load->model('jurusan_model');
	//	$this->load->library('grocery_crud');
		//$this->load->library('gcharts');
	
	}
	public function index()
	{
		$this->data_jurusan();
	}
	public function home()
	{
	//	$this->	
		$this->load->view('view_home'); //memanggil view home.php
	}
	public function mahasiswa() 
	{
		$this->load->view('view_mahasiswa'); //memanggil view kuliah.php
	}
	public function karyawan()
	{
		$this->load->view('view_karyawan'); //memanggil view kerja.php
	}
	public function dosen()
	{
		$this->load->view('view_dosen'); //memanggil view aboutme.php
	}
	public function data_jurusan()
	{
		//memanggil fungsi tampil_jurusan di jurusan_model
		$var['tabel'] = $this->jurusan_model->tampil_jurusan();

		//memanggil library template - fungsi jurusan, serta mengirim variabel $var
		$this->template->tampil_jurusan($var); 
	}
	
}
