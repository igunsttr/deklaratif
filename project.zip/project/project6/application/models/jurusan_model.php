<?php if(!defined('BASEPATH')) exit ('Access Denied'); 
class Jurusan_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->library('table');
		$this->load->helper('text','date');
		$this->load->view_data['base_url']=base_url();
	//	$this->load->library('access');
	}
	public function index()
	{
		$this->tampil_jurusan();	
	}
	
	public function tampil_jurusan()
	{

		//Memanggil library table, menerapkan style dari fungsi template	
		$this->table->set_template($this->template());

		//Membuat header tabel 
		$this->table->set_heading('No','Nama Jurusan','');			

		// melakukan query sql 'select no, nama jurusan from jurusan' menggunakan cara CodeIgniter
		$query=$this->db->select('no, nama_jurusan');
		$query=$this->db->get('jurusan');

		//jika hasil query lebih dari 0 baris(ada data di tabel jurusan)
		if ($query->num_rows() > 0)
				{

				//perulangan utk menampilkan isi tabel jurusan
				foreach ($query->result() as $row)
				{

					$this->table->add_row(
					
					//ucwords adalah fungsi untuk membuat kalimat menjadi Sentence Case
					ucwords($row->no),
					ucwords($row->nama_jurusan),
					
					//menambahkan button edit di kolom ketiga
					'<a href='.base_url().'index.php/home/jurusan/edit/'.$row->no.'><button type="button" class="btn btn-primary btn-sm"> Edit </button></a>'
								
					);
				}	
				// generate table
				$this->output_table = $this->table->generate(); 

				//mengembalikan hasil tabel ke controller jurusan
				return $this->output_table;
				}
		else
		{
			return FALSE;
		}

	}


	public function template()
	{
		$style=array('table_open' => '<table class="table table-striped table-hover ">'
		
		,'heading_row_start' => '<tr>'
		,'heading_row_end' => '</tr>'
		,'heading_cell_start' => '<th>'
		,'heading_cell_end' => '</th>'
						
		,'row_start' => '<tr>'
		,'cell_start' => '<td>'
		,'cell_end' => '</td>'	
		
		,'row_alt_start' => '<tr>'
		,'row_alt_end' => '</tr>'
		,'cell_alt_start' => '<td>'
		,'cell_alt_end' => '</td>'
						
		,'table_close' => '</table>'
		);	
		return $style;
	}


}
